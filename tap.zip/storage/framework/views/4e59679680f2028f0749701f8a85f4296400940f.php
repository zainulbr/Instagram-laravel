<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('title'); ?> | FILGRAM</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/css/sb-admin-2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/font-awesome/css/font-awesome.min.css')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <?php echo $__env->yieldContent('header-additional'); ?>
</head>
<body>
<?php echo $__env->make('partials.header_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.header_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row" style="margin-top: 40px">

            <?php echo $__env->yieldContent('content'); ?>
        
    </div>

<script type="text/javascript" src="<?php echo e(url('assets/js/jquery-1.12.3.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('assets/js/sb-admin-2.js')); ?>"></script>

<?php echo $__env->yieldContent('footer-additional'); ?>
</body>
</html>