Report

<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

           <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tables</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>

            <!--Field Tables-->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">

                        <div class="panel-heading">
                            Report User Tables
                        </div>

                        <!--Panel Body Tables -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">

                                <!--Isi Tabel-->
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Reporter</th>
                                            <th>Reason</th>
                                            <th>User</th>
                                            <th>Time Report</th>
                                            <th>Status</th>
                                            <th>Post</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($reports) != 0): ?>
                                        <?php foreach($reports as $r): ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo e($r['id']); ?></td>
                                            <td><?php echo e($r['reporter']); ?></td>
                                            <td><?php echo e($r['reason']); ?></td>
                                            <td><?php echo e($r['username']); ?></td>
                                            <td><?php echo e($r['created_at']); ?></td>
                                            <td><?php echo e($r['status']); ?></td>
                                            <td>
                                                  <a href="#"
                                                  <button type="submit" class="btn btn-warning btn-sm">Go to Post</button>
                                                  </a>
                                            </td>
                                            <td>
                                                 <a href="#"
                                                  <button type="submit" class="btn btn-danger btn-sm">Delete Post</button>
                                                  </a>
                                                
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                  </tbody>
                                </table>
                                <!--Akhir isi Tabel-->
                                
                            </div>
                               <div class="col-md-offset-4 col-md-4">
                                <?php if(Session::has('status')): ?>
                                    <div class="alert alert-<?php echo e(Session::get('status')); ?>" role="alert">
                                        <strong><?php echo e(Session::get('title')); ?></strong><br/>
                                        <h5><?php echo e(Session::get('status')); ?></h5>
                                    </div>
                                <?php endif; ?>
                                    
                            </div>
        </div>
            <!--
                        </div>
                        <!--Akhir Panel Body Tables -->
                    </div>
                </div>
            </div>
            <!--Akhir Field Tables-->
        </div>
        <!--Akhir Page Utama -->
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>