   <!--Navbar Kiri-->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="{{route('user-admin')}}"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        
                        <li>
                            <a href="{{route('user-tabel')}}"><i class="fa fa-users fa-fw"></i> User Tables</a>
                        </li>

                        <li>
                            <a href="{{route('user-report')}}"><i class="fa fa-fax fa-fw"></i> Report Tables</a>
                        </li>

                    </ul>
                </div>
            </div>
            <!--Akhir Navbar Kiri-->
        </nav>
        <!--Akhir Navigation-->