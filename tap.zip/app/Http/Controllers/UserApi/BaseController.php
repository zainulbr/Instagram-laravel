<?php

namespace App\Http\Controllers\UserApi;

use App\Http\Controllers\ApiController;

class BaseController extends ApiController
{
}